# Andrey Xavier — Portfólio

Site estático em HTML, CSS e JavaScript. Extraia o ZIP e abra index.html, mantendo assets/ ao lado do arquivo.

## Projeto atual
analise-xp-inc: estudo independente da ação da XP Inc. Etapa atual: coleta e limpeza. SQL, Power BI, automação e integração com IA são etapas futuras.

As informações de progresso foram fornecidas pelo autor. Os resultados ainda não foram verificados pelo site.

## Ideias futuras
Radar de vagas, análise de avaliações, qualidade de planilhas, assistente de estudos e acompanhamento de candidaturas. Todas ainda sem implementação.
